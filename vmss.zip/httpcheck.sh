#!/bin/bash

while :
do
    echo ""
    curl -L http://reg1pubappgw-pip.westeurope.cloudapp.azure.com
    sleep 1
done
